# Bubble-sheet-grading-using-OMR
This is an project about computer vision, It use to grade student's test. This software is made in python use OpenCV liburary and Tkinter liburary.
